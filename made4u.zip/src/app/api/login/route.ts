import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import connectDB from "@/lib/db";
import User from "@/models/User";
import jwt from "jsonwebtoken";

export async function POST(req: Request) {
  try {
    console.log("📌 เริ่มเชื่อมต่อ MongoDB...");
    await connectDB();
    console.log("✅ เชื่อมต่อสำเร็จ!");

    const { email, password } = await req.json();
    console.log("📌 ข้อมูลที่รับมา:", { email });

    // ค้นหาผู้ใช้ในฐานข้อมูล
    const user = await User.findOne({ email });
    if (!user) {
      console.log("❌ ไม่พบผู้ใช้:", email);
      return NextResponse.json({ message: "อีเมลหรือรหัสผ่านไม่ถูกต้อง" }, { status: 400 });
    }

    // ตรวจสอบรหัสผ่าน
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      console.log("❌ รหัสผ่านไม่ถูกต้อง");
      return NextResponse.json({ message: "อีเมลหรือรหัสผ่านไม่ถูกต้อง" }, { status: 400 });
    }

    // สร้าง Token (JWT)
    const token = jwt.sign({ id: user._id, email: user.email }, process.env.JWT_SECRET!, {
      expiresIn: "7d",
    });

    console.log("✅ Login สำเร็จ:", user.email);
    return NextResponse.json({ message: "เข้าสู่ระบบสำเร็จ", token }, { status: 200 });
  } catch (error) {
    console.error("❌ อีเมลหรือรหัสผ่านไม่ถูกต้อง:", error);
    return NextResponse.json({ message: "อีเมลหรือรหัสผ่านไม่ถูกต้อง", error }, { status: 500 });
  }
}
