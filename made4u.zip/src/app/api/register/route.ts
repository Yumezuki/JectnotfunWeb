import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import connectDB from "@/lib/db";
import User from "@/models/User";

export async function POST(req: Request) {
  try {
    console.log("📌 เริ่มเชื่อมต่อ MongoDB...");
    await connectDB();
    console.log("✅ เชื่อมต่อสำเร็จ!");

    const { name, phone, email, password } = await req.json();
    console.log("📌 ข้อมูลที่รับมา:", { name, phone, email, password });

    // ตรวจสอบว่ามีผู้ใช้ที่ใช้ email นี้อยู่หรือไม่
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      console.log("❌ อีเมลซ้ำ:", email);
      return NextResponse.json({ message: "อีเมลนี้ถูกใช้แล้ว" }, { status: 400 });
    }

    // เข้ารหัสรหัสผ่านก่อนบันทึกลงฐานข้อมูล
    const hashedPassword = await bcrypt.hash(password, 10);
    console.log("🔐 รหัสผ่านที่ถูกเข้ารหัส:", hashedPassword);

    // บันทึกข้อมูลผู้ใช้ในฐานข้อมูล
    const newUser = new User({ name, phone, email, password: hashedPassword });
    await newUser.save();
    console.log("✅ บันทึกสำเร็จ:", newUser);

    return NextResponse.json({ message: "สมัครสมาชิกสำเร็จ" }, { status: 201 });
  } catch (error) {
    console.error("❌ เกิดข้อผิดพลาด:", error);
    return NextResponse.json({ message: "เกิดข้อผิดพลาด", error }, { status: 500 });
  }
}
