import { NextResponse } from "next/server";
import connectDB from "@/lib/db";
import User from "@/models/User";

export async function GET() {
  await connectDB();

  try {
    const user = await User.findOne({ email: "test@example.com" }); // ใช้ email จริง
    if (!user) return NextResponse.json({ message: "User not found" }, { status: 404 });

    return NextResponse.json(user);
  } catch (error) {
    return NextResponse.json({ error: "Error fetching profile" }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  await connectDB();
  const data = await req.json();

  try {
    const updatedUser = await User.findOneAndUpdate({ email: "test@example.com" }, data, { new: true });
    return NextResponse.json(updatedUser);
  } catch (error) {
    return NextResponse.json({ error: "Error updating profile" }, { status: 500 });
  }
}
