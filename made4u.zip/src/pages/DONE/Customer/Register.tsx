"use client";
import React, { useState } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import '@/app/globals.css';
import Link from "next/link";

const RegisterPage = () => {
  const [user, setUser] = useState({
    name: "",
    phone: "",
    email: "",
    password: "",
    confirmPassword: "",
  });
  const router = useRouter();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
  
    if (user.password !== user.confirmPassword) {
      alert("รหัสผ่านไม่ตรงกัน!");
      return;
    }

    console.log(user);
  
    const res = await fetch("/api/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(user),
    });
  
    const data = await res.json();
    if (res.ok) {
      alert("สมัครสมาชิกสำเร็จ!");
      router.push("/DONE/Customer/Login");
    } else {
      alert(data.message);
    }
  };  

  return (
    <div className="flex h-screen items-center justify-center bg-rose-50">
      <div className="bg-white rounded-lg shadow-lg flex">
        <div className="flex w-xs items-center justify-center pl-10">
          <Image src="/image/doll.png" alt="doll" width={200} height={200} />
        </div>
        <div className="p-8 w-96">
          <h2 className="text-3xl text-center text-rose-300">ลงทะเบียน</h2>
          <form onSubmit={handleRegister} className="mt-4">

          <div className="mb-4">
              <label className="block text-gray-700 text-md">ชื่อ-นามสกุล</label>
              <input
                type="Text"
                name="name" 
                value={user.name}
                onChange={handleChange}
                className="w-full p-2 border border-gray-200 rounded mt-1 focus:outline focus:outline-rose-300"
                placeholder="ชื่อ-นามสกุล"
                required
              />
            </div>

            <div className="mb-4">
              <label className="block text-gray-700 text-md">เบอร์โทรศัพท์</label>
              <input
                type="Text"
                name="phone"
                value={user.phone}
                onChange={handleChange}
                className="w-full p-2 border border-gray-200 rounded mt-1 focus:outline focus:outline-rose-300"
                placeholder="เบอร์โทรศัพท์"
                required
              />
            </div>

            <div className="mb-4">
              <label className="block text-gray-700 text-md">อีเมลผู้ใช้</label>
              <input
                type="email"
                name="email" 
                value={user.email} 
                onChange={handleChange}
                className="w-full p-2 border border-gray-200 rounded mt-1 focus:outline focus:outline-rose-300"
                placeholder="อีเมล"
                required
              />
            </div>

            <div className="mb-4">
              <label className="block text-gray-700 text-md">
                ตั้งรหัสผ่านใหม่
              </label>
              <input
                type="password"
                name="password" 
                value={user.password} 
                onChange={handleChange}
                className="w-full p-2 border border-gray-200 rounded mt-1 focus:outline focus:outline-rose-300"
                placeholder="กรอกรหัสผ่านใหม่"
                required
              />
            </div>

            <div className="mb-4">
              <label className="block text-gray-700 text-md">
                ยืนยันรหัสผ่านอีกครั้ง
              </label>
              <input
                type="password"
                name="confirmPassword" 
                value={user.confirmPassword} 
                onChange={handleChange}
                className="w-full p-2 border border-gray-200 rounded mt-1 focus:outline focus:outline-rose-300"
                placeholder="กรอกรหัสผ่านอีกครั้ง"
                required
              />
            </div>

            <button
              type="submit"
              className="w-full bg-rose-300 text-white p-2 rounded-lg hover:bg-rose-400 transition"
            >
              สมัครสมาชิก
            </button>
          </form>
          <p className="text-center  text-gray-600 mt-4">
            <Link href="/DONE/Customer/Login" className="text-rose-300 hover:underline">
              เข้าสู่ระบบ
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default RegisterPage;
