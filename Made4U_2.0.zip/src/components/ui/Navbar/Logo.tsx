import Link from "next/link";

const Logo = () => {
  return (
    <Link href="/DONE/Customer/Home" className="text-2xl font-bold ">
      <span className="text-[#CAA8E3]">Made</span>
      <span className="text-[#FFA1A1]">4U</span>
    </Link>
  );
};

export default Logo;
