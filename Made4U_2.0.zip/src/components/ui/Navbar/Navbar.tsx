"use client";

import Logo from "./Logo";
import Search from "./Search";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ShoppingCart, Package, User } from "lucide-react";
import { useState } from "react";
import { FiMenu, FiX } from "react-icons/fi"; // ใช้ไอคอนเมนูและปิด

const Navbar = () => {
  const router = useRouter();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <nav className="max-w-[1700px] mx-auto bg-white-100 border-b border-gray-300">
      <div className="container flex justify-between items-center py-5 px-4 md:px-10 lg:px-0">
        {/* Logo */}
        <Logo />

        {/* Navigation Links - Desktop */}
        <div className="hidden md:flex gap-6 text-gray-700">
          <Link href="/DONE/Customer/Home" className="text-black hover:text-black transition">ร้านค้า</Link>
          <Link href="Order" className="text-black hover:text-black transition">รายการคำสั่งซื้อ</Link>
        </div>

        {/* Search Bar */}
        <Search />

        {/* Icons */}
        <div className="hidden md:flex gap-6 text-black">
          <ShoppingCart 
            className="cursor-pointer hover:text-black transition"
            onClick={() => router.push("/DONE/Customer/Cart")}
          />
          <Package 
            className="cursor-pointer hover:text-black transition"
            onClick={() => router.push("/DONE/Customer/Tracking")}
           />
          <User
            className="cursor-pointer hover:text-black transition"
            onClick={() => router.push("/DONE/Customer/Profile")}
          />
        </div>

        {/* Mobile Menu Button */}
        <div className="md:hidden flex items-center">
          <button
            className="text-black text-2xl"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <FiX /> : <FiMenu />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white py-4 px-4 flex flex-col gap-4 text-gray-700 border-t border-gray-300">
          <Link href="#" className="text-black hover:text-black transition">ร้านค้า</Link>
          <Link href="#" className="text-black hover:text-black transition">New Arrivals</Link>
          <div className="flex gap-6 text-black mt-4">
          <ShoppingCart 
            className="cursor-pointer hover:text-black transition"
            onClick={() => router.push("/DONE/Customer/Cart")}
          />
          <Package 
            className="cursor-pointer hover:text-black transition"
            onClick={() => router.push("/DONE/Customer/Tracking")}
           />
            <User
              className="cursor-pointer hover:text-black transition"
              onClick={() => router.push("/DONE/Customer/Profile")}
            />
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;