import { FaTwitter, FaFacebook, FaInstagram, FaGithub } from "react-icons/fa";

const Footer = () => {
  return (
    <footer className="bg-gray-100 py-10 mt-auto text-center md:text-left">
      <div className="max-w-6xl mx-auto px-8 flex flex-col md:flex-row justify-between gap-8">
        <div className="flex-1">
          <h2 className="text-3xl font-bold text-[#CAA8E3]">
            Made<span className="text-[#FFA1A1]">4U</span>
          </h2>
          <p className="mt-4 text-sm text-gray-600">
            ออกแบบดีไซน์ในแบบของคุณ<br />ให้คุณได้ครอบครองความเป็นเอกลักษณ์<br />และความพิเศษในแบบของตัวเอง
          </p>
          <div className="flex justify-center md:justify-start gap-4 mt-6">
            <a href="#" className="text-gray-500 hover:text-gray-800"><FaTwitter size={24} /></a>
            <a href="#" className="text-gray-500 hover:text-gray-800"><FaFacebook size={24} /></a>
            <a href="#" className="text-gray-500 hover:text-gray-800"><FaInstagram size={24} /></a>
            <a href="#" className="text-gray-500 hover:text-gray-800"><FaGithub size={24} /></a>
          </div>
        </div>
        <div className="flex-1 text-center md:text-right">
          <h3 className="font-semibold mb-2">RESOURCES</h3>
          <ul className="space-y-2 text-sm text-gray-600">
            <li><a href="#" className="hover:text-gray-800">Free eBooks</a></li>
            <li><a href="#" className="hover:text-gray-800">Development Tutorial</a></li>
            <li><a href="#" className="hover:text-gray-800">How to - Blog</a></li>
            <li><a href="#" className="hover:text-gray-800">Youtube Playlist</a></li>
          </ul>
        </div>
      </div>
      <div className="text-center text-xs text-gray-500 mt-8">
        Shop.co © 2000-2023, All Rights Reserved
      </div>
    </footer>
  );
};

export default Footer;