module.exports = {
  plugins: {
    '@tailwindcss/postcss': {},  // ใช้แพ็กเกจใหม่นี้แทน
    autoprefixer: {},
  },
}
